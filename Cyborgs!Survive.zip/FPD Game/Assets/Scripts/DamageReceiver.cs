﻿using UnityEngine;

public class DamageReceiver : MonoBehaviour, IEntity
{
    //This script will keep track of player HP
    public float playerHP = 100;
    public SC_CharacterController playerController;
    public WeaponManager weaponManager;

    public void ApplyDamage(float points)
    {
        playerHP -= points;

        if (playerHP <= 0)
        {
            //Player is dead
            playerController.canMove = false;
            playerHP = 0;
        }
    }
    public  void Healregen(GameObject other)
    {
        if (playerHP >= 50 && playerHP < 100)
        {
            playerHP = 100;
            Destroy(other);
        }
        else if (playerHP < 50)
        {
            playerHP += 50;
            Destroy(other);
        }
        
    }
}