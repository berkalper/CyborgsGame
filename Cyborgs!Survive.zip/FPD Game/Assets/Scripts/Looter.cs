﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Looter : MonoBehaviour
{
    public Transform[] spawnPoints;
    public GameObject[] arrayfab;
    public float spawnInterval = 12;
    public float loottimer = 12;
    float nextSpawnTime = 0;
    bool waitingForLoot = true;
    void Update()
    {
        if (loottimer >= 0)
        {
            loottimer -= Time.deltaTime;
        }
        else
        { 
            int randomnumber = Random.Range(0, spawnPoints.Length);
            Transform randomPoint = spawnPoints[randomnumber];
            GameObject enemy = Instantiate(arrayfab[Random.Range(0,arrayfab.Length)], randomPoint.position, Quaternion.identity);
            loottimer = spawnInterval;
        }
        
    }
}
