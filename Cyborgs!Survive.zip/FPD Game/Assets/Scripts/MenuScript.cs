﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class MenuScript : MonoBehaviour
{
    public GameObject ınstructıonpage;
    public GameObject page1;
    public GameObject page2;
    public GameObject levels;
    public Button prevbut;
    public Button nextbut;
    public TextMeshProUGUI pager;
  public void Play()
    {
        levels.SetActive(true);
    }
    public void level1()
    {
        SceneManager.LoadScene("NewLevel");
    }
    public void level2()
    {
        SceneManager.LoadScene("nochange");
    }
    public void OpenInstructıons()
    {
        ınstructıonpage.SetActive(true);
    }
    public void NextPage()
    {
        page1.SetActive(false);
        page2.SetActive(true);
        nextbut.interactable = false;
        prevbut.interactable = true;
        pager.text = "Page 2/2";
        
    }
    public void PrevPage()
    {
        page1.SetActive(true);
        page2.SetActive(false);
        nextbut.interactable = true;
        prevbut.interactable = false;
        pager.text = "Page 1/2";

    }
    public void CloseInstructıons()
    {
        ınstructıonpage.SetActive(false);
        levels.SetActive(false);
    }
    public void Exit()
    {
        Application.Quit();
    }
}
