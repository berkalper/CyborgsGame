﻿using UnityEngine;

[RequireComponent(typeof(CharacterController))]

public class SC_CharacterController : MonoBehaviour
{
    public float speed = 7.5f;
    public float jumpSpeed = 8.0f;
    public float gravity = 20.0f;
    public Camera playerCamera;
    public float lookSpeed = 2.0f;
    public float lookXLimit = 45.0f;
    float speedctr=0;
    int grdctr =2;
    public GameObject ball;
    
    

    CharacterController characterController;
    Vector3 moveDirection = Vector3.zero;
    Vector2 rotation = Vector2.zero;

    [HideInInspector]
    public bool canMove = true;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
        rotation.y = transform.eulerAngles.y;
        GameObject.Find("EnemySpawner").GetComponent<EnemySpawner>().updategrdctr(grdctr);
    }

    void Update()
    {
        if (speedctr >= 0)
        {
            speedctr -= Time.deltaTime;
        }
        if (speedctr > 0)
        {
            speed = 15f;
        }
        else
        {
            speed = 7.5f;
        }
        if (characterController.isGrounded)
        {
            // We are grounded, so recalculate move direction based on axes
            Vector3 forward = transform.TransformDirection(Vector3.forward);
            Vector3 right = transform.TransformDirection(Vector3.right);
            float curSpeedX = canMove ? speed * Input.GetAxis("Vertical") : 0;
            float curSpeedY = canMove ? speed * Input.GetAxis("Horizontal") : 0;
            moveDirection = (forward * curSpeedX) + (right * curSpeedY);

            if (Input.GetButton("Jump") && canMove)
            {
                moveDirection.y = jumpSpeed;
            }
        }

        moveDirection.y -= gravity * Time.deltaTime;

        // Move the controller
        characterController.Move(moveDirection * Time.deltaTime);

        // Player and Camera rotation
        if (canMove)
        {
            rotation.y += Input.GetAxis("Mouse X") * lookSpeed;
            rotation.x += -Input.GetAxis("Mouse Y") * lookSpeed;
            rotation.x = Mathf.Clamp(rotation.x, -lookXLimit, lookXLimit);
            playerCamera.transform.localRotation = Quaternion.Euler(rotation.x, 0, 0);
            transform.eulerAngles = new Vector2(0, rotation.y);
        }
        if (Input.GetKeyDown(KeyCode.G)&& grdctr>0)
        {
            ThrowBall();
            grdctr--;
            GameObject.Find("EnemySpawner").GetComponent<EnemySpawner>().updategrdctr(grdctr);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag.Equals("Heal"))
        {
            gameObject.GetComponentInChildren<DamageReceiver>().Healregen(other.gameObject);
           
        }
        else if (other.gameObject.tag.Equals("SpeedUp"))
        {
            speedctr += 15;
            Debug.Log("I AM SPEED");
            Destroy(other.gameObject);
        }
        else if (other.gameObject.tag.Equals("Circuit"))
        {
            grdctr++;
            Destroy(other.gameObject);
            GameObject.Find("EnemySpawner").GetComponent<EnemySpawner>().updategrdctr(grdctr);
        }
    }
    public void ThrowBall()
    {
        GameObject ThrowedBall = Instantiate(ball, playerCamera.transform.position + playerCamera.transform.forward * 2, Quaternion.identity) as GameObject;
        ThrowedBall.gameObject.GetComponent<Rigidbody>().AddForce(playerCamera.transform.forward * 1500);
        GameObject.Destroy(ThrowedBall, 5f);
    }
}
