﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


    interface IEntity
    {
        void ApplyDamage(float points);
    }
